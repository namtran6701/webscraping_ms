#!/bin/bash

# set environment variables from .env file for the script to authenticate using service principal
# Load environment variables from .env file
if [ -f .env ]; then
  echo "Loading environment variables from .env file..."
  export $(grep -v '^#' .env | xargs)
else
  echo ".env file not found."
  exit 1
fi

# install niet if not installed
if ! command -v niet &> /dev/null; then
  echo "Installing niet..."
  pip install niet
fi

# Navigate to the directory of the script
cd "$(dirname "$0")"
# Load variables from YAML file using niet
config_file="config.yaml"

# Extract required values from config.yaml
FunctionAppName=$(niet "variables.FunctionAppName" $config_file)
FunctionAppResourceGroup=$(niet "variables.ResourceGroupName" $config_file)
AzureSubscriptionId=$(niet "variables.SubscriptionId" $config_file)
FunctionAppRuntime=$(niet "variables.FunctionAppRuntime" $config_file)
TestFunctionEndpoint=$(niet "variables.TestFunctionEndpoint" $config_file)
AzureFunctionsFolder=$(niet "variables.AzureFunctionsFolder" $config_file)  # Folder containing your Azure functions
YAMLPath=$(niet "variables.YAMLPath" $config_file)
MainYAMLPath=$(niet "variables.MainYAMLPath" $config_file)
ContainerConfig=$(niet "variables.ContainerConfig" $config_file)
ContainerBlob=$(niet "variables.ContainerBlob" $config_file)
AzureStorageAccountKey=$(niet "variables.AzureStorageAccountKey" $config_file)
AzureStorageAccountName=$(niet "variables.StorageAccountName" $config_file)
StorageAccountUrl=$(niet "variables.StorageAccountUrl" $config_file)


# check if the initialization of all variables is successful
if [ -z "$FunctionAppName" ] || [ -z "$FunctionAppResourceGroup" ] || [ -z "$AzureSubscriptionId" ] || [ -z "$FunctionAppRuntime" ] || [ -z "$TestFunctionEndpoint" ] || [ -z "$AzureFunctionsFolder" ]; then
  echo "Failed to load variables from config file."
  exit 1
fi

# Conda environment name
CONDA_ENV_NAME="functionapp_deploy_env"

# Step 1: Set up Conda environment
echo "Setting up Conda environment..."

# Check if the environment already exists
if conda info --envs | grep -q "$CONDA_ENV_NAME"; then
  echo "Conda environment '$CONDA_ENV_NAME' already exists. Activating it..."
else
  echo "Creating Conda environment '$CONDA_ENV_NAME' with Python 3.10..."
  conda create -y -n "$CONDA_ENV_NAME" python=3.10
fi

# Activate the Conda environment
source "$(conda info --base)/etc/profile.d/conda.sh"
conda activate "$CONDA_ENV_NAME"


# Step 2: Copy YAML file to Azure Storage Container
echo "Copying YAML file to Azure Storage container..."

# Define the YAML file and container name
yaml_file_path=$YAMLPath

# Step 3: Authenticate Azure CLI
echo "Authenticating with Azure CLI..."
az account set --subscription "$AzureSubscriptionId"

# Check if the container exists, if not create it
az storage container create \
  --account-name "$AzureStorageAccountName" \
  --name "$ContainerConfig" \
  --account-key "$AzureStorageAccountKey" \

# Upload the YAML file to the storage container
az storage blob upload \
  --account-name "$AzureStorageAccountName" \
  --container-name "$ContainerConfig" \
  --name "crawlers.yaml" \
  --file "$yaml_file_path" \
  --account-key "$AzureStorageAccountKey" \
  --overwrite true

# Upload the YAML file to the storage container
az storage blob upload \
  --account-name "$AzureStorageAccountName" \
  --container-name "$ContainerConfig" \
  --name "main.yaml" \
  --file "$MainYAMLPath" \
  --account-key "$AzureStorageAccountKey" \
  --overwrite true

# Check if the upload was successful
if [ $? -eq 0 ]; then
  echo "YAML file uploaded successfully to Azure Storage container '$ContainerConfig'."
else
  echo "Error occurred while uploading YAML file to Azure Storage container."
  exit 1
fi

# Step 4: Install requirements
echo "Installing requirements..."
cd "$AzureFunctionsFolder" || exit
pip install -r requirements.txt

# Step 3: Authenticate Azure CLI
echo "Authenticating with Azure CLI..."
az account set --subscription "$AzureSubscriptionId"


# Step 5: Deploy function app code
echo "Deploying function code to Azure..."

# Specify the path to the function you want to deploy (e.g., webcrawler)
func_name="webcrawler"
func_dir="$AzureFunctionsFolder"  # Path to the function directory

# Check if the function directory exists
if [ ! -d "$func_dir" ]; then
  echo "Function directory '$func_dir' does not exist."
  exit 1
fi

# Navigate to the function directory
cd "$func_dir" || exit

az functionapp config appsettings set --name "$FunctionAppName" \
  --resource-group "$FunctionAppResourceGroup" \
  --settings CRAWLER_CONFIGURATION_STORAGE_ACCOUNT_URL="$StorageAccountUrl" CRAWLER_CONFIGURATION_CONTAINER_NAME="$ContainerConfig" PYTHONDONTWRITEBYTECODE=1

max_retries=2
retry_count=0
while [ $retry_count -lt $max_retries ]; do
    # Try to deploy
    func azure functionapp publish "$FunctionAppName" \
      --resource-group "$FunctionAppResourceGroup" \
      --subscription "$AzureSubscriptionId" \
      --runtime "$FunctionAppRuntime" \
      --python --force && break

    # Wait and retry if deployment fails
    echo "Deployment failed, retrying in 10 seconds..."
    sleep 10
    ((retry_count++))
done

# Check if the function deployment was successful
if [ $? -eq 0 ]; then
  echo "Function '$func_name' deployed successfully."
else
  echo "Error occurred during deployment of function '$func_name'."
  exit 1
fi

# Step 6: Test the deployed Azure Function
echo "Testing the deployed function..."

# Test the function using curl (or similar method)
curl -X GET "$TestFunctionEndpoint"  # Assuming it's a GET request endpoint

# Check if the curl command was successful
if [ $? -eq 0 ]; then
  echo "Function test completed successfully."
else
  echo "Error occurred during function test."
  exit 1
fi

# Display success message if all steps are successful
echo "Function deployment completed successfully."


# Display success message if all steps are successful
echo "Function deployment and YAML upload completed successfully."

# Clean up the Conda environment
conda deactivate
conda env remove --name "$CONDA_ENV_NAME"
