"""Azure Function to run Crawler every 4 hours."""

import logging
import os
import json
from datetime import datetime

import azure.functions as func

app = func.FunctionApp(http_auth_level=func.AuthLevel.FUNCTION)


_logger = logging.getLogger(__name__)
logging.getLogger("azure").setLevel(logging.WARNING)


@app.function_name(name="crawler")
@app.timer_trigger(
    schedule="0 */2 * * * *",
    arg_name="crawlertimer",
    run_on_startup=False,
)
def crawler(crawlertimer: func.TimerRequest) -> None:
    """Crawler timer function.

    Args:
        crawlertimer (func.TimerRequest): timer request

    Raises:
        e: raise exception when failed to run crawler
    """
    _build_id = os.getenv("BUILD_ID", "Local Build")
    _utc_timestamp = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    if crawlertimer.past_due:
        _logger.info("Crawler Run: The timer is past due for build id %s!", _build_id)
    _logger.info(
        "Crawler Run: Python timer trigger function ran at %s for build id %s",
        _utc_timestamp,
        _build_id,
    )
    try:
        from webcrawler import WebCrawler

        _crawler = WebCrawler()
        _crawler.crawl()
        _logger.info(
            "Completed web crawler for build id %s",
            _build_id,
        )
    except Exception as e:
        _logger.error(
            "Failed to run web crawler",
            exc_info=e,
        )
        raise e